﻿using Dapper.Application.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dapper.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IUnitOfWork unitOfWork;
        public ProductController(IUnitOfWork UnitOfWork)
        {
            this.unitOfWork = UnitOfWork;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var data = await unitOfWork.ProductRepository.GetAllAsync();
                return Ok(data);
            }
            catch (Exception ex) {
                  return NotFound();
            }
        }
    }
}
